python src/main.py --input graph/karate.edgelist --output emb/karate.emd
